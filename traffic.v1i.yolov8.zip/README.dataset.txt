# traffic > 2024-12-19 3:50pm
https://universe.roboflow.com/test-mlayv/traffic-ufbey

Provided by a Roboflow user
License: CC BY 4.0

